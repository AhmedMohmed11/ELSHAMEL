    div class="course-with-video-2" style=" direction: rtl; ">

    <section class="course-info-card-2" style="margin-top: 89px; ">
        <article class="card-2">
            <img width="330" src="img/chimistry-img.jpg" class="img-card-2">
            <div style="width: 200;" class="content-2-card">
                <h1 class="title-card-2">تعلم أساسيات الكيمياء</h1>
                <p class="description-card-2">
                    تهدف هذه الدورة الى تطوير مهاراتك في الكيمياء
                </p>
                <hr>
                <div class="content-of-course-2" style="direction: rtl;">
                    <i class="fa-solid fa-video" style="color: #74C0FC; display: inline-block;"></i>
                    <h1 style="display: inline-block; font-size: 17px;">دروس مسجلة</h1>
                    <div class="content-2">
                        <i class="fa-solid fa-children" style="color: #74C0FC;"></i>
                        <h1 style="display: inline-block; font-size: 17px;">للطلاب والطالبات </h1>
                    </div>


                </div>
                <hr>

            </div>
            <div class="flex" style="justify-content: space-between;">
                <div class="price-1" style="font-weight: 500; color: black;">200 SR</div>


            </div>



        </article>
        </main>